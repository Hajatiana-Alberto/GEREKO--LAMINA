# GEREKO et LAMINA
Deux applications Android hors connexion. Les données sont conservées localement sur le téléphone.

## Compilation automatique
Après avoir ajouté ces fichiers à la branche `main` du dépôt GitHub, ouvrir l'onglet **Actions**, sélectionner **Construire les APK Android**, puis **Run workflow**. À la fin, télécharger l'artefact `GEREKO-LAMINA-APK` et extraire les deux fichiers APK.

Applications de démonstration initiales : à enrichir selon les tableaux PDF originaux.
